
//Sun Apr 11 17:22:54 BST 2010
//
//<>PROJ<>
//

#include <gnome.h>
#include <glib/gstdio.h>
#include <glib.h>

#define VERSION "0.0.0"

gchar *data=NULL;
gboolean version = FALSE;

static GOptionEntry entries[] = 
{
	{ "long1", 'l', 0, G_OPTION_ARG_STRING,&data, "A long option with one string arg", "String" },
	{ "version", 'v', 0, G_OPTION_ARG_NONE, &version, "Print version",NULL },
	{ NULL }
};


int main(int argc, char **argv)
{

  GError *error = NULL;
  GOptionContext *context;

  context = g_option_context_new ("- Gnome based CLI app");
  g_option_context_add_main_entries (context, entries,NULL);
  g_option_context_add_group (context, gtk_get_option_group (TRUE));
  if (!g_option_context_parse (context, &argc, &argv, &error))
    {
      g_print ("option parsing failed: %s\n", error->message);
      exit (1);
    }
	
	if (version==TRUE)
		{
		printf("<>APP<> %s\n",VERSION);
		return 0;
		}

	if (data!=NULL)
		printf("long1 ARG= %s\n",data);

	printf("%s\n","Hello World");
	return 0;
}

