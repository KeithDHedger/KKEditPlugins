#include "<>PROJ<>.h"

int
main( int    argc,
      char * argv[ ] )
{
    fl_initialize( &argc, argv, 0, 0, 0 );


     create_the_forms( );


     /* Fill-in form initialization code */

    /* Show the first form */

    fl_show_form( mainForm, FL_PLACE_CENTER, FL_FULLBORDER, "mainForm" );
    fl_do_forms( );

    return 0;
}
