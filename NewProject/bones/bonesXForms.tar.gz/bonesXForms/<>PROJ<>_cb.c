/*
 *
 * ©K. D. Hedger. Tue 31 Jul 12:35:52 BST 2018 keithdhedger@gmail.com

 * This file (<>PROJ<>_cb.c) is part of <>PROJ<>.

 * <>PROJ<> is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.

 * <>PROJ<> is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with bones.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <libgen.h>

#include "<>PROJ<>.h"

/* Callbacks and freeobj handles for form mainForm */

/***************************************
 ***************************************/

void doWhat( FL_OBJECT * ob,long data )
{
    switch (data)
    	{
    		case 1:
    			printf("Hello world\n");
    			break;
    		case 2:
    			exit(0);
    			break;
    	}
}
