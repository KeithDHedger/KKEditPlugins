#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <libgen.h>

#include "<>PROJ<>.h"

/* Callbacks and freeobj handles for form mainForm */

/***************************************
 ***************************************/

void doWhat( FL_OBJECT * ob,long data )
{
    switch (data)
    	{
    		case 1:
    			printf("Hello world\n");
    			break;
    		case 2:
    			exit(0);
    			break;
    	}
}




