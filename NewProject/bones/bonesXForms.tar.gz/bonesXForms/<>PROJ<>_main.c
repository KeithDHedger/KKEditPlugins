/*
 *
 * ©K. D. Hedger. Tue 31 Jul 12:34:17 BST 2018 keithdhedger@gmail.com

 * This file (<>PROJ<>_main.c) is part of <>PROJ<>.

 * <>PROJ<> is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.

 * <>PROJ<> is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with bones.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "<>PROJ<>.h"

int
main( int    argc,
      char * argv[ ] )
{
    fl_initialize( &argc, argv, 0, 0, 0 );


     create_the_forms( );


     /* Fill-in form initialization code */

    /* Show the first form */

    fl_show_form( mainForm, FL_PLACE_CENTER, FL_FULLBORDER, "mainForm" );
    fl_do_forms( );

    return 0;
}
