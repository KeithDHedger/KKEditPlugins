
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "config.h"

#ifdef _USEQT5_
#include <QApplication>
#include <QWidget>
#include <QMessageBox>
#else
#include <gtk/gtk.h>
#endif

#ifndef _USEQT5_
GtkWidget *dialog = NULL;

void shutdown(GtkWidget* widget,gpointer data)
{
	gtk_main_quit();
}
#endif

int main(int argc, char **argv)
{

#ifdef _USEQT5_
	QApplication	app(argc, argv);
	QMessageBox		msgBox;

	msgBox.setText("Hello World!");
	msgBox.show();
	return app.exec();
#else
	gtk_init(&argc,&argv);

	dialog=gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_CLOSE,"Hello World!");
	gtk_dialog_run((GtkDialog*)dialog);
#endif
}

