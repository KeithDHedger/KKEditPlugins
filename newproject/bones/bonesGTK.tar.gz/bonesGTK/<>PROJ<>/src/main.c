
//Mon 31 Jul 2006 12:30:55 BST 

//
// <>PROJ<>
//

#include <gnome.h>
#include <glade/glade.h>
#include <glib/gstdio.h>
#include <glib.h>

#include "globals.h"

void on_mainwindow_destroy(GtkObject *object, gpointer user_data)
{
	g_printf("\n%s\n","BYE!");
	gtk_main_quit();
	return TRUE;
}

void runAScript(gchar *commandLine)
{
	g_warning("%s",commandLine);
	g_spawn_command_line_sync(commandLine,NULL,NULL,NULL,NULL);
}

void okclicked(GtkObject *object, gpointer user_data)
{
	g_printf("ok clicked\n");
}

void cancelclicked(GtkObject *object, gpointer user_data)
{
	g_printf("cancel clicked\n");
}

int main(int argc, char **argv)
{
	
	GnomeProgram	*program;
	unsigned int	cnt=0;

	program = gnome_program_init(PROGRAMNAME, "0.1",
                               LIBGNOMEUI_MODULE,
                               argc, argv,
                               GNOME_PROGRAM_STANDARD_PROPERTIES,
                               GNOME_PARAM_HUMAN_READABLE_NAME, "<>PROJ<>",
                               NULL);

	if (g_file_test(GLADEFILE,G_FILE_TEST_EXISTS)==TRUE)
		{
		gladepath=GLADEFILE;
		prefixPathToPix=PATHTOPIX;
		prefixPathToScripts=PATHTOSCRIPTS;
		}
	else
		{
		gladepath=gnome_program_locate_file(program,GNOME_FILE_DOMAIN_APP_DATADIR,GLADENAME,TRUE,NULL);
		prefixPathToPix=gnome_program_locate_file(program,GNOME_FILE_DOMAIN_APP_DATADIR,"pixmaps",TRUE,NULL);
		prefixPathToScripts=gnome_program_locate_file(program,GNOME_FILE_DOMAIN_APP_DATADIR,"scripts",TRUE,NULL);
		}

	mainui = gtk_builder_new ();
	gtk_builder_add_from_file (mainui,gladepath, NULL);
	mainwindow = GTK_WIDGET(gtk_builder_get_object (mainui, "mainwindow"));
	gtk_builder_connect_signals (mainui, NULL);          
        g_object_unref (G_OBJECT (mainui));
        
        gtk_widget_show (mainwindow);  	
	gtk_main();
	return 0;
}

